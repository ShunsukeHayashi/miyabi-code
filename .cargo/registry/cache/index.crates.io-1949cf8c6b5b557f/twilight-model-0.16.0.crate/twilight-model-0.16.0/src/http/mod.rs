//! Models used when sending data to Discord.

pub mod attachment;
pub mod channel_position;
pub mod interaction;
pub mod permission_overwrite;
