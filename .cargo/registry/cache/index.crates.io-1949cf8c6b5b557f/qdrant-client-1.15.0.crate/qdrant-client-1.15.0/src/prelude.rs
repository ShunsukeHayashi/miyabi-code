#![allow(deprecated)]

pub use crate::client::*;
pub use crate::qdrant::{
    point_id, CreateCollection, DeleteCollection, Distance, PointStruct, SearchPoints, Value,
};
