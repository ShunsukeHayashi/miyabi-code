use axum_extra::routing::TypedPath;

#[derive(TypedPath)]
#[typed_path("")]
struct MyPath;

fn main() {}
