use axum_macros::debug_handler;

#[debug_handler]
struct A;

fn main() {}
