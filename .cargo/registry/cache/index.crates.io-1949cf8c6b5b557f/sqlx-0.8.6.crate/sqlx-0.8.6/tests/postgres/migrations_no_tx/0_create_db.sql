-- no-transaction

CREATE DATABASE test_db;
