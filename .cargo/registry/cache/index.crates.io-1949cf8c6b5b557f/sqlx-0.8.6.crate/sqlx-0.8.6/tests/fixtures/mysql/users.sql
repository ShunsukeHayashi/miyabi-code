insert into user(user_id, username)
values (1, 'alice'), (2, 'bob');
