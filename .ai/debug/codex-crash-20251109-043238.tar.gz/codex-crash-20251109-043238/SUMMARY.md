# Codex Crash Debug Report

**Generated**: 2025-11-09T04:32:42+09:00
**Event ID**: test-003
**Severity**: P0

---

## Event Details

```json
{
  "eventId": "test-003",
  "reason": "Test debug collection",
  "severity": "P0",
  "details": {
    "errorMessage": "Mock crash for testing",
    "recentLogs": ["line 1", "line 2", "line 3"]
  }
}
```

---

## Files Collected

-rw-r--r--@ 1 shunsuke  staff     0B Nov  9 04:32 SUMMARY.md
-rw-r--r--@ 1 shunsuke  staff   580B Nov  9 04:32 codex-notify-2025-11-09.log
-rw-r--r--@ 1 shunsuke  staff   330B Nov  9 04:32 codex-restart-2025-11-09.log
-rw-r--r--@ 1 shunsuke  staff   953B Nov  9 04:32 disk-usage.txt
-rw-r--r--@ 1 shunsuke  staff   1.5K Nov  9 04:32 environment.txt
-rw-r--r--@ 1 shunsuke  staff   224B Nov  9 04:32 event-metadata.json
-rw-r--r--@ 1 shunsuke  staff     5B Nov  9 04:32 git-branch.txt
-rw-r--r--@ 1 shunsuke  staff   525K Nov  9 04:32 git-diff.txt
-rw-r--r--@ 1 shunsuke  staff   728B Nov  9 04:32 git-log.txt
-rw-r--r--@ 1 shunsuke  staff    35K Nov  9 04:32 git-status.txt
-rw-r--r--@ 1 shunsuke  staff   601B Nov  9 04:32 git-worktrees.txt
-rw-r--r--@ 1 shunsuke  staff    66B Nov  9 04:32 macos-version.txt
-rw-r--r--@ 1 shunsuke  staff   1.1K Nov  9 04:32 memory-usage.txt
-rw-r--r--@ 1 shunsuke  staff    17K Nov  9 04:32 process-info.txt
-rw-r--r--@ 1 shunsuke  staff   2.3K Nov  9 04:32 recent-commands-zsh.txt
-rw-r--r--@ 1 shunsuke  staff   1.5K Nov  9 04:32 recent-commands.txt
-rw-r--r--@ 1 shunsuke  staff   143B Nov  9 04:32 system-info.txt

---

## System Information

- **OS**: Darwin
- **Version**: 25.0.0
- **Architecture**: arm64
- **Hostname**: MacBook-Pro-3.local
- **User**: shunsuke

---

## Git Information

- **Branch**: main
- **Commit**: 5878b61f0d28935ea5b4dcb4b32df90e70d77e6e
- **Worktree**: /Users/shunsuke/Dev/miyabi-private

---

## Next Steps

1. Review logs in this directory
2. Check `git-diff.txt` for uncommitted changes
3. Examine `stdout-tail-200.log` and `stderr-tail-200.log` for error patterns
4. Verify system resources in `memory-usage.txt` and `disk-usage.txt`

