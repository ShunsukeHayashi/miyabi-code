import React from 'react';
import { motion } from 'framer-motion';
import { Button } from './Button';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden border-b border-zinc-900">
      {/* Abstract Digital Swarm Background */}
      <div className="absolute inset-0 z-0 flex items-center justify-center opacity-30">
         <motion.div 
           animate={{ rotate: 360 }}
           transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
           className="w-[150vw] h-[150vw] border-[1px] border-dashed border-zinc-800 rounded-full flex items-center justify-center"
         >
            <div className="w-[80%] h-[80%] border-[1px] border-dashed border-zinc-800 rounded-full flex items-center justify-center">
              <div className="w-[60%] h-[60%] border-[1px] border-zinc-800 rounded-full"></div>
            </div>
         </motion.div>
      </div>

      <div className="z-10 text-center px-4 max-w-6xl mx-auto">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h2 className="font-mono text-sm md:text-lg text-zinc-500 tracking-[0.3em] mb-4 uppercase">
            From Pixel To EC2. The Ultimate Hierarchy.
          </h2>
          <h1 className="font-display font-black text-5xl md:text-8xl lg:text-9xl tracking-tighter leading-[0.9] mb-8 text-white uppercase">
            One Command.<br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-600">
              250 Million Agents.
            </span>
          </h1>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="flex flex-col md:flex-row gap-6 justify-center mt-12"
        >
          <Button onClick={() => window.location.hash = 'terminal'}>
            INITIALIZE SYSTEM
          </Button>
          <Button variant="secondary">
             READ MANIFESTO
          </Button>
        </motion.div>
      </div>
      
      <div className="absolute bottom-12 left-0 w-full flex justify-center">
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-zinc-600 text-xs tracking-widest uppercase"
        >
          Scroll to decrypt
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;