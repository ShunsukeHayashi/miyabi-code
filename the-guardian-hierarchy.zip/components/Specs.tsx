import React from 'react';
import { motion } from 'framer-motion';

const SpecItem: React.FC<{ label: string; value: string; sub?: string; delay: number }> = ({ label, value, sub, delay }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay, duration: 0.5 }}
    className="flex flex-col border-t border-zinc-800 p-8 hover:bg-white/5 transition-colors"
  >
    <span className="font-display text-4xl md:text-6xl font-bold text-white mb-2">{value}</span>
    <span className="font-mono text-xs tracking-[0.2em] text-zinc-500 uppercase mb-1">{label}</span>
    {sub && <span className="font-mono text-xs text-zinc-700">{sub}</span>}
  </motion.div>
);

const Specs: React.FC = () => {
  return (
    <section id="specs" className="w-full bg-cyber-black py-20 border-b border-zinc-900">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-0">
          <SpecItem label="Agent Capacity" value="250M+" sub="Dynamic Scaling" delay={0.1} />
          <SpecItem label="Latency" value="<0.1ms" sub="Neural Response" delay={0.2} />
          <SpecItem label="Infrastructure" value="AWS EC2" sub="Full Spectrum Access" delay={0.3} />
          <SpecItem label="Hierarchy" value="Lv. 0" sub="God Mode (Guardian)" delay={0.4} />
        </div>
      </div>
    </section>
  );
};

export default Specs;