import React, { useEffect, useState, useRef } from 'react';

const logs = [
  "> SYSTEM_INIT: START",
  "> AUTH: GUARDIAN_ID_VERIFIED",
  "> CONNECTING TO LOCAL_MAESTRO...",
  "> MAESTRO: CONNECTION_ESTABLISHED [0.002ms]",
  "> INPUT RECEIVED: 'Target market domination'",
  "> MAESTRO: PARSING INTENT...",
  "> DEPLOYING STRATEGY: AGGRESSIVE",
  "> CONNECTING TO AWS_EC2_NORTH_VIRGINIA...",
  "> PROVISIONING INSTANCES...",
  "> SWARM: 50,000 AGENTS ONLINE",
  "> SWARM: 250,000 AGENTS ONLINE",
  "> SWARM: 1,000,000 AGENTS ONLINE",
  "> SWARM: 25,000,000 AGENTS ONLINE",
  "> SWARM: 250,000,000 AGENTS READY",
  "> WAITING FOR COMMAND..."
];

const Terminal: React.FC = () => {
  const [displayLogs, setDisplayLogs] = useState<string[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex < logs.length) {
        const nextLog = logs[currentIndex];
        if (nextLog) {
             setDisplayLogs(prev => [...prev, nextLog]);
        }
        currentIndex++;
      } else {
        clearInterval(interval);
      }
    }, 300);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [displayLogs]);

  return (
    <section id="terminal" className="py-20 bg-[#0a0a0a] border-y border-zinc-900">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-between mb-4">
             <h3 className="font-mono text-xs text-zinc-500 uppercase tracking-widest">Live System Log</h3>
             <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-zinc-800"></div>
                <div className="w-3 h-3 rounded-full bg-zinc-800"></div>
                <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
             </div>
        </div>
        
        <div className="w-full bg-black border border-zinc-800 p-6 h-[300px] overflow-hidden font-mono text-sm md:text-base relative shadow-2xl">
            <div className="absolute top-0 left-0 w-full h-full pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-20 bg-[length:100%_2px,3px_100%]"></div>
            <div className="space-y-2 text-emerald-500 opacity-80">
                {displayLogs.map((log, index) => {
                  if (!log) return null;
                  return (
                    <div key={index} className={`${log.includes("ERROR") ? "text-red-500" : ""} ${log.includes("WAITING") ? "animate-pulse text-white" : ""}`}>
                        {log}
                    </div>
                  );
                })}
                <div ref={bottomRef} />
            </div>
        </div>
        
        <div className="mt-8 flex justify-end">
             <button className="font-display uppercase text-xs tracking-widest border-b border-zinc-700 pb-1 hover:text-white hover:border-white transition-colors">
                Full Diagnostics Report
             </button>
        </div>
      </div>
    </section>
  );
};

export default Terminal;