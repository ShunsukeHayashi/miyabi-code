import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
  className?: string;
}

export const Button: React.FC<ButtonProps> = ({ children, onClick, variant = 'primary', className = '' }) => {
  const baseStyle = "font-display uppercase tracking-widest px-8 py-4 text-sm md:text-base transition-all duration-300 border border-transparent";
  
  const variants = {
    primary: "border-cyber-silver text-cyber-silver hover:bg-cyber-silver hover:text-cyber-black hover:shadow-[0_0_20px_rgba(255,255,255,0.4)]",
    secondary: "border-zinc-800 text-zinc-500 hover:border-cyber-silver hover:text-cyber-silver"
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`${baseStyle} ${variants[variant]} ${className}`}
      onClick={onClick}
    >
      {children}
    </motion.button>
  );
};