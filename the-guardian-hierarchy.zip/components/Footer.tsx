import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-12 border-t border-zinc-900 text-center">
      <div className="font-display text-2xl font-bold tracking-widest text-zinc-800 uppercase mb-4">
        Guardian Hierarchy
      </div>
      <p className="font-mono text-xs text-zinc-600 uppercase tracking-widest">
        © 2024 All Systems Operational. Power is absolute.
      </p>
    </footer>
  );
};

export default Footer;