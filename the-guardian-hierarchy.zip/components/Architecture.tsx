import React from 'react';
import { motion } from 'framer-motion';
import { Smartphone, Cpu, Server, ChevronDown } from 'lucide-react';

interface LayerProps {
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
  isLast?: boolean;
}

const Layer: React.FC<LayerProps> = ({ title, subtitle, description, icon, isLast }) => {
  return (
    <div className="relative flex flex-col md:flex-row items-start md:items-center gap-8 py-16 group">
      {!isLast && (
        <div className="absolute left-[27px] md:left-[43px] top-[80px] md:top-[100px] bottom-[-40px] w-[1px] bg-zinc-800 group-hover:bg-emerald-900 transition-colors"></div>
      )}
      
      <div className="relative z-10 flex-shrink-0 w-14 h-14 md:w-24 md:h-24 border border-zinc-800 bg-cyber-black flex items-center justify-center text-zinc-500 group-hover:text-white group-hover:border-white transition-all duration-500">
        {icon}
      </div>

      <div className="flex-grow">
        <h3 className="font-mono text-emerald-500 text-xs tracking-[0.3em] mb-2 uppercase">{subtitle}</h3>
        <h2 className="font-display text-3xl md:text-5xl font-bold text-white mb-4 uppercase">{title}</h2>
        <p className="font-mono text-zinc-500 max-w-2xl text-sm md:text-base leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
};

const Architecture: React.FC = () => {
  return (
    <section id="architecture" className="bg-cyber-black py-24 relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h2 className="font-display text-4xl md:text-6xl font-black uppercase mb-4">The Hierarchy</h2>
          <div className="h-1 w-24 bg-emerald-500"></div>
        </motion.div>

        <div className="flex flex-col">
          <Layer 
            title="The Guardian" 
            subtitle="Level 1: You"
            description="The highest layer. No complex code. Just natural language commands issued via Pixel interface. You conduct the symphony; the system handles the chaos."
            icon={<Smartphone className="w-6 h-6 md:w-10 md:h-10" />}
          />
          
          <Layer 
            title="The Maestro" 
            subtitle="Level 2: Local Orchestrator"
            description="Operating locally on high-performance silicon (MacBook). The Maestro translates your intent into tactical directives, bridging the gap between human will and machine execution."
            icon={<Cpu className="w-6 h-6 md:w-10 md:h-10" />}
          />

          <Layer 
            title="The Swarm" 
            subtitle="Level 3: AWS EC2"
            description="Full scale infrastructure mobilization. Coordinators seize cloud resources to spawn 250 million operator agents instantly. Unrivaled computational violence."
            icon={<Server className="w-6 h-6 md:w-10 md:h-10" />}
            isLast
          />
        </div>
      </div>
    </section>
  );
};

export default Architecture;