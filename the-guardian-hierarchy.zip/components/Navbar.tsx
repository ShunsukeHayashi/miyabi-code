import React from 'react';
import { Shield } from 'lucide-react';

const Navbar: React.FC = () => {
  return (
    <nav className="fixed top-0 w-full z-40 mix-blend-difference px-6 py-6 flex justify-between items-center">
      <div className="flex items-center gap-2">
        <Shield className="w-6 h-6" />
        <span className="font-display font-bold tracking-widest hidden md:block">GUARDIAN</span>
      </div>
      <div className="flex gap-8 text-xs md:text-sm tracking-widest font-bold">
        <a href="#specs" className="hover:text-white transition-colors opacity-70 hover:opacity-100">SPECS</a>
        <a href="#architecture" className="hover:text-white transition-colors opacity-70 hover:opacity-100">HIERARCHY</a>
        <a href="#terminal" className="hover:text-white transition-colors opacity-70 hover:opacity-100">SYSTEM LOG</a>
      </div>
      <div className="hidden md:block text-xs text-emerald-500 animate-pulse">
        SYSTEM: ONLINE
      </div>
    </nav>
  );
};

export default Navbar;