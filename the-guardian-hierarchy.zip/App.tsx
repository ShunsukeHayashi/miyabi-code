import React, { useEffect, useState } from 'react';
import Hero from './components/Hero';
import Architecture from './components/Architecture';
import Specs from './components/Specs';
import Terminal from './components/Terminal';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import { AnimatePresence, motion } from 'framer-motion';

const App: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Simulate system boot sequence
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="font-mono text-cyber-silver min-h-screen flex flex-col relative selection:bg-cyber-silver selection:text-cyber-black">
      
      {/* Background Grid Effect */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-20" 
           style={{
             backgroundImage: `linear-gradient(#222 1px, transparent 1px), linear-gradient(90deg, #222 1px, transparent 1px)`,
             backgroundSize: '40px 40px'
           }}>
      </div>
      
      {/* Scanline Effect */}
      <div className="fixed inset-0 pointer-events-none z-50 scanline"></div>

      <AnimatePresence>
        {!isLoaded ? (
          <motion.div 
            key="loader"
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-cyber-black flex-col"
          >
            <div className="text-xl font-display tracking-[0.5em] animate-pulse">INITIALIZING GUARDIAN PROTOCOL...</div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="relative z-10 flex flex-col w-full"
          >
            <Navbar />
            <main className="flex-grow">
              <Hero />
              <Specs />
              <Architecture />
              <Terminal />
            </main>
            <Footer />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;